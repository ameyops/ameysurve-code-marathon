
import './App.css';
import { R } from './Routes/Router';


function App() {
  return (
    
    <div className="App">
      <R/>
    </div>
    
  );
}

export default App;
