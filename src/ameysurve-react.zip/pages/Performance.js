import React from 'react'
import MatchForm from '../models/mform'
export const Form = () => {
  return (
    <div>
      <MatchForm/>
    </div>
  )
}
export default Form;
